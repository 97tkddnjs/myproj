package com.dboard.myproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
